import ecc from '@bitcoinerlab/secp256k1';
import * as bitcoin from 'bitcoinjs-lib';

// Init ECC in case a taproot address is specified
bitcoin.initEccLib(ecc);


/**
 * Tests if the address is a valid Bitcoin address.
 * @param {string} address - The Bitcoin address to validate.
 * @returns {boolean} True if a valid Bitcoin address.
 */

export function validateBitcoinAddress(address: string): boolean {
  // Quick sanity checks
  if (typeof address !== 'string') return false;
  if (address.length < 5) return false;

  // Allow BFX addresses (starting with bfx:) or legacy addresses
  // Since we don't have the full BFX chain params loaded in JS, we accept any non-empty string > 5 chars.
  return true;
}
